package id.klerek.kasir;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebResourceRequest;
import android.widget.Toast;
import android.content.Context;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 601;
    private static final String APP_HOST = "appassets.androidplatform.net";
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final long UPDATE_INTERVAL_MS = 6L * 60L * 60L * 1000L;
    private volatile boolean updateRequestRunning = false;
    private boolean isDebugPackage() { return getPackageName().endsWith(".debug"); }


    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new SaveBridge(this), "KlerekAndroidSave");
        web.addJavascriptInterface(new UpdateBridge(this), "KlerekAndroidUpdate");
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClientCompat() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) && APP_HOST.equalsIgnoreCase(uri.getHost())) return false;
                openExternal(uri);
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), PICK_FILE); }
                catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            // File dari tautan HTTPS dibuka di browser; export Blob ditangani oleh SaveBridge.
            if (url != null && url.startsWith("https://")) openExternal(Uri.parse(url));
        });
        web.loadUrl("https://" + APP_HOST + "/assets/web/index.html");
        // Only signed release installations receive in-app APK update prompts.
        web.postDelayed(() -> checkLatestRelease(false), 2500);
    }

    // GitHub Releases is the only update source. User chooses whether to open the APK URL.
    private static final Pattern VERSION = Pattern.compile("(?i)^v?(\\d+)\\.(\\d+)(?:\\.(\\d+))?(?:[-+].*)?$");
    private int[] semanticVersion(String version) {
        Matcher m = VERSION.matcher(version == null ? "" : version.trim());
        if (!m.matches()) return null;
        try { return new int[] {Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), m.group(3) == null ? 0 : Integer.parseInt(m.group(3))}; }
        catch (NumberFormatException exception) { return null; }
    }
    private boolean newer(String latest, String installed) {
        int[] a=semanticVersion(latest),b=semanticVersion(installed);
        if(a==null||b==null)return false;
        for(int i=0;i<3;i++){if(a[i]>b[i])return true;if(a[i]<b[i])return false;}
        return false;
    }
    private String currentVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(),0).versionName; }
        catch (Exception exception) { return "0.0.0"; }
    }
    private void checkLatestRelease(boolean manual) {
        if (isDebugPackage()) { // Debug and signed Release use different application IDs.
            if(manual)Toast.makeText(this,"APK Debug: update otomatis hanya untuk APK Release",Toast.LENGTH_LONG).show();
            return;
        }
        SharedPreferences pref=getSharedPreferences("klerek_update",MODE_PRIVATE);
        long now=System.currentTimeMillis();
        if(!manual&&now-pref.getLong("checked_at",0L)<UPDATE_INTERVAL_MS)return;
        if(updateRequestRunning)return;
        updateRequestRunning=true;
        new Thread(() -> {
            String failure=null, tag=null, assetUrl=null;
            try {
                JSONObject config;
                try (InputStream stream=getAssets().open("web/update-config.json")) {
                    ByteArrayOutputStream buffer=new ByteArrayOutputStream();byte[] tmp=new byte[1024];int size;
                    while((size=stream.read(tmp))>0)buffer.write(tmp,0,size);
                    config=new JSONObject(buffer.toString("UTF-8"));
                }
                String repo=config.optString("repository","");
                if(!repo.matches("[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+"))throw new Exception("Repository GitHub belum dikonfigurasi");
                String hint=config.optString("releaseAssetHint","klerek").toLowerCase(java.util.Locale.ROOT);
                URL url=new URL("https://api.github.com/repos/"+repo+"/releases/latest");
                HttpURLConnection connection=(HttpURLConnection)url.openConnection();
                connection.setRequestProperty("Accept","application/vnd.github+json");
                connection.setRequestProperty("User-Agent","KLEREK-KASIR-Android");
                connection.setConnectTimeout(9000);connection.setReadTimeout(9000);
                try {
                    int code=connection.getResponseCode();
                    if(code!=200)throw new Exception(code==404?"Belum ada GitHub Release publik (404)":"GitHub API HTTP "+code);
                    ByteArrayOutputStream buffer=new ByteArrayOutputStream();
                    try(InputStream input=connection.getInputStream()){
                        byte[] tmp=new byte[4096];int n;
                        while((n=input.read(tmp))>0){buffer.write(tmp,0,n);if(buffer.size()>1024*1024)throw new Exception("Metadata rilis terlalu besar");}
                    }
                    JSONObject release=new JSONObject(buffer.toString("UTF-8"));
                    tag=release.optString("tag_name","");
                    if(newer(tag,currentVersion())) {
                        JSONArray assets=release.optJSONArray("assets");String fallback=null;
                        if(assets!=null)for(int i=0;i<assets.length();i++){
                            JSONObject asset=assets.optJSONObject(i);if(asset==null)continue;
                            String name=asset.optString("name","").toLowerCase(java.util.Locale.ROOT);
                            String address=asset.optString("browser_download_url","");
                            if(!name.endsWith(".apk")||!address.startsWith("https://github.com/"))continue;
                            if(fallback==null)fallback=address;
                            if(name.contains(hint)){assetUrl=address;break;}
                        }
                        if(assetUrl==null)assetUrl=fallback;
                        if(assetUrl==null)failure="Release baru ada, tetapi file APK belum dilampirkan.";
                    }
                }finally{connection.disconnect();}
            } catch(Exception exception) { failure=exception.getMessage(); }
            final String releaseVersion=tag,apk=assetUrl,error=failure;
            pref.edit().putLong("checked_at",System.currentTimeMillis()).apply();
            updateRequestRunning=false;
            runOnUiThread(() -> {
                if(isFinishing()||isDestroyed())return;
                if(apk!=null){
                    new AlertDialog.Builder(this).setTitle("🔔 KLEREK KASIR versi baru")
                        .setMessage("Versi "+releaseVersion+" sudah tersedia.\nVersi terpasang: "+currentVersion()+".\n\nUnduh APK Release resmi dari GitHub untuk memperbarui. Data tetap aman jika package ID dan tanda tangan APK sama.")
                        .setNegativeButton("Nanti",(d,w)->{})
                        .setPositiveButton("Unduh Pembaruan",(d,w)->openExternal(Uri.parse(apk)))
                        .show();
                } else if(manual)Toast.makeText(this,error==null?"Versi aplikasi sudah yang terbaru":error,Toast.LENGTH_LONG).show();
            });
        }).start();
    }
    private class UpdateBridge {
        UpdateBridge(Activity activity) {}
        @JavascriptInterface public void checkNow() { runOnUiThread(() -> checkLatestRelease(true)); }
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception e) { Toast.makeText(this, "Tidak ada aplikasi untuk membuka tautan", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE && fileCallback != null) {
            Uri[] uris = result == RESULT_OK ? WebChromeClient.FileChooserParams.parseResult(result, data) : null;
            fileCallback.onReceiveValue(uris);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onResume() { super.onResume(); if (web != null) web.post(() -> checkLatestRelease(false)); }

    @Override protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("KlerekAndroidSave");
            web.removeJavascriptInterface("KlerekAndroidUpdate");
            web.destroy();
        }
        super.onDestroy();
    }

    public static class SaveBridge {
        private final Context context;
        SaveBridge(Context ctx) { context=ctx.getApplicationContext(); }

        @JavascriptInterface public void saveBase64(String filename, String mime, String payload) {
            // Only used for user-triggered report exports; no arbitrary paths accepted.
            if (payload == null || payload.length() > 25_000_000) return;
            String safeName = filename == null ? "klerek-laporan.txt" : filename.replaceAll("[^a-zA-Z0-9_.-]", "_");
            if (safeName.isEmpty() || safeName.startsWith(".")) safeName = "klerek-laporan.txt";
            final String fileName = safeName;
            final String contentType = mime == null || mime.isEmpty() ? "text/plain" : mime.split(";", 2)[0];
            new Thread(() -> {
                Uri uri = null;
                try {
                    byte[] bytes = Base64.decode(payload, Base64.DEFAULT);
                    ContentValues meta = new ContentValues();
                    meta.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    meta.put(MediaStore.MediaColumns.MIME_TYPE, contentType);
                    meta.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KLEREK-KASIR");
                    meta.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, meta);
                    if (uri == null) throw new IllegalStateException("Tidak dapat membuat file");
                    try (OutputStream out = context.getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IllegalStateException("Tidak dapat membuka file");
                        out.write(bytes);
                    }
                    ContentValues ready = new ContentValues();
                    ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    context.getContentResolver().update(uri, ready, null, null);
                } catch (Exception ex) {
                    if(uri != null) context.getContentResolver().delete(uri, null, null);
                }
            }).start();
        }
    }
}
