// KLEREK KASIR v4.5.0 — satu project Supabase bersama RankMate Kasir.
// Publishable Key aman untuk aplikasi klien; jangan gunakan service_role/secret key.
// DATA TETAP TERPISAH: KLEREK memakai tabel/fungsi 'klerek_*', RankMate 'rankmate_*'.
// Skema SQL KLEREK harus dipasang terpisah di project ini sebelum login siap digunakan.
window.KLEREK_SUPABASE_CONFIG = {
  url: 'https://jcmhjmvudpquapzcajfe.supabase.co',
  publishableKey: 'sb_publishable_Pxq878Q8gkIsQz2lsG-b1A_zDlOiC83'
};
