// KONFIGURASI KLEREK KASIR — project Supabase KHUSUS KLEREK.
// Isi sebelum build bila login harus langsung aktif. Jangan pakai secret/service_role.
window.KLEREK_SUPABASE_CONFIG = {
  url: '',                 // https://<PROJECT_ID>.supabase.co
  publishableKey: ''       // sb_publishable_... (key publik, bukan rahasia)
};
