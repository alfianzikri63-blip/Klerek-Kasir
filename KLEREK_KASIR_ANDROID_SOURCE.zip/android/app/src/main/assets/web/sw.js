// KLEREK KASIR standalone Android assets — SW tidak digunakan oleh WebView.
self.addEventListener('install', event => { self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(self.clients.claim()); });
