'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/web/index.html'),'utf8');
const start=src.indexOf('// v4.6.4 — reconciliation for officer drafts.');
const end=src.indexOf('function v458OfficerPersistDrafts(){',start);
assert(start>=0 && end>start);
const context={
 V45:{autoDraftKeys:new Set(['shop:2026-11-21:3:2']),autoExpected:new Map([['shop:2026-11-21:3:2',3]]),autoErrors:new Map(),autoSending:new Set(),autoTimers:new Map(),drafts:new Map([['shop:2026-11-21:3:2',[{pickup:6408000,etrans:2751500,pln:54500}]]])},
 cloud:{ready:true,storeId:'shop'},
 state:{date:'2026-11-21'},
 v45DraftKey:(si,ci)=>`shop:2026-11-21:${si+1}:${ci+1}`,
 v45Check:()=>null,
 v4IsManager:()=>true,
 totals:({rows})=>{const p=rows.reduce((a,b)=>a+b.pickup,0),e=rows.reduce((a,b)=>a+b.etrans,0),l=rows.reduce((a,b)=>a+b.pln,0);return {net:p-e-l};},
 money:n=>'Rp '+n,
 esc:x=>String(x),
 v458OfficerPersistDrafts:()=>{},
 cloudUpdateBadge:()=>{},
 clearTimeout:()=>{},
 assert
};
vm.runInNewContext(src.slice(start,end)+`
const serverOld={work_date:'2026-11-21',shift:3,slot:2,revision:4,pickup:6408000,etrans:0,pln:54775,lines:[{pickup:6408000,etrans:0,pln:54775}]};
v464OfficerReconcileRow(serverOld);
assert(V45.autoDraftKeys.has('shop:2026-11-21:3:2'));
assert.match(V45.autoErrors.get('shop:2026-11-21:3:2'),/KONFLIK/);
assert(v464OfficerPendingPane().includes('Cadangkan draft'));
assert(v464OfficerPendingPane().includes('Simpan input HP'));
const now={...serverOld,revision:5,etrans:2751500,pln:54500,lines:[{pickup:6408000,etrans:2751500,pln:54500}]};
v464OfficerReconcileRow(now);
assert.equal(V45.autoDraftKeys.size,0);
assert.equal(V45.autoErrors.size,0);
assert.equal(V45.drafts.size,0);
`,context);
assert.match(src,/if\(V45\.autoDraftKeys\.has\(v45DraftKey\(si,ci\)\)\)return null/);
assert.match(src,/v464OfficerReconcileRow\(row\)/);
assert.match(src,/v464OfficerResolve\(btn\.dataset\.v464OfficerKey/);
console.log('PASS v4.6.4: mismatch keeps draft + gives conflict options, matching cloud auto-acks pending, stale badge hidden');
