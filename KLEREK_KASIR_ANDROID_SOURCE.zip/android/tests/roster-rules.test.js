'use strict';
const assert=require('node:assert/strict');
const K=require('../app/src/main/assets/web/schedule-import.js');
const p=(nik,name,role,codes,order)=>({nik,name,role,codes,order});
const roster={version:1,period:'2026-11',dates:['2026-11-19','2026-11-20'],staff:[
 p('0224042745','Kasir Perempuan A','CASHIER',{'2026-11-20':'P7','2026-11-19':'M22'},1),
 p('0225111111','Kasir Perempuan B','CASHIER',{'2026-11-20':'S14'},2),
 p('0226111111','Kasir Perempuan C','CASHIER',{'2026-11-20':'S14'},3),
 p('0218045659','Crew Lama','CREW',{'2026-11-20':'P7','2026-11-19':'M22'},4),
 p('0224042746','Crew Muda','CREW',{'2026-11-20':'P7','2026-11-19':'M22'},5),
]};
const x=K.calculate(roster,'2026-11-20');
assert.equal(x.shifts[0][0].name,'Kasir Perempuan A','Kasir 1 selalu CASHIER');
assert.equal(x.shifts[0][1].name,'Crew Muda','Kasir 2 CREW dengan NIK numerik tertinggi');
assert.equal(x.shifts[1][0].role,'CASHIER');
assert.equal(x.shifts[1][1].role,'CASHIER','Dua perempuan, tidak mengambil CREW');
assert.equal(x.shifts[2][0].name,'Kasir Perempuan A','Shift 3 menggunakan M22 tanggal sebelumnya');
assert.equal(x.shifts[2][1].nik,'0224042746');
assert.ok(K.compareNik('0224042745','0218045659')>0,'Contoh aturan NIK');
const lacking={...roster,staff:roster.staff.filter(x=>x.role!=='CASHIER')};
const y=K.calculate(lacking,'2026-11-20');
assert.equal(y.shifts[0][0],null);
assert.equal(y.shifts[0][1].name,'Crew Muda','Crew bertugas tetap terlihat sebagai Kasir 2 meski tidak ada CASHIER');
assert.ok(y.issues.some(x=>x.includes('TIDAK ADA kasir perempuan')));
assert.equal(y.shifts[2][0].nik,'0224042746','Shift 3 dapat memakai CREW saat STAFF tidak tersedia');
assert.equal(y.shifts[2][1].nik,'0218045659','Crew kedua tetap terpilih dari M22 H-1');
const onlyOne={...roster,staff:[p('0226086689','RULLY AKBAR','CREW',{'2026-11-20':'M22'},10)]};
const z=K.calculate(onlyOne,'2026-11-21');
assert.equal(z.shifts[2][0].name,'RULLY AKBAR','21 November menampilkan crew M22 dari 20 November');
assert.equal(z.shifts[2][1],null,'Satu orang tidak boleh menempati dua slot');
const fallback={...roster,staff:[p('0226086689','RULLY','CREW',{'2026-11-21':'M22'},10),p('0231000001','DINDA','CASHIER',{'2026-11-21':'M22'},11)]};
const f=K.calculate(fallback,'2026-11-21');
assert.equal(f.shifts[2][0].name,'DINDA','Kasir H digunakan bila H-1 tidak ada STAFF');
assert.equal(f.shifts[2][1].name,'RULLY','Crew M22 H digunakan sebagai pendamping');
const twoCrew={...roster,staff:[p('0226086689','RULLY','CREW',{'2026-11-20':'M22'},10),p('0226086690','ERI','CREW',{'2026-11-21':'M22'},11)]};
const tc=K.calculate(twoCrew,'2026-11-21');
assert.equal(tc.shifts[2][0].name,'ERI','Saat dua CREW, NIK tertinggi menjadi Kasir 1');
assert.equal(tc.shifts[2][1].name,'RULLY','Crew dengan NIK lebih kecil menjadi Kasir 2');
console.log('PASS: female priority, NIK descending, Shift 3 H-1, crew displayed without female, warning retained');
