'use strict';
const assert=require('node:assert/strict');
const K=require('../app/src/main/assets/web/schedule-import.js');
const p=(nik,name,role,codes,order)=>({nik,name,role,codes,order});
const d19='2026-11-19',d20='2026-11-20',d21='2026-11-21',d22='2026-11-22';
const roster={version:2,period:'2026-11',dates:[d19,d20,d21,d22],staff:[
 p('0300000001','Staff Awal','STAFF',{[d19]:'M22',[d20]:'P7'},2),
 p('0300000002','Staff Tengah','STAFF',{[d20]:'M22'},3),
 p('0300000003','Crew Awal','CREW',{[d19]:'M22',[d20]:'S14'},4),
 p('0300000004','Crew Tengah','CREW',{[d20]:'M22',[d21]:'M22'},5),
 p('0300000005','Crew Besok','CREW',{[d21]:'M22'},6),
 p('0300000006','Kasir Pagi','CASHIER',{[d20]:'P7'},7),
 p('0300000007','Kasir Siang 1','CASHIER',{[d20]:'S14'},8),
 p('0300000008','Kasir Siang 2','CASHIER',{[d20]:'S14'},9),
]};
let r=K.calculate(roster,d20);
assert.deepEqual(r.shifts[2].map(x=>x?.name),['Staff Awal','Crew Awal']);
assert.ok(r.shifts[2].every(x=>x.sourceDate===d19),'Both Shift 3 slots must be M22 H-1');
assert.deepEqual(r.shifts[0].map(x=>x?.name),['Kasir Pagi',undefined]);
assert.deepEqual(r.shifts[1].map(x=>x?.name),['Kasir Siang 1','Kasir Siang 2']);
r=K.calculate(roster,d21);
assert.deepEqual(r.shifts[2].map(x=>x?.name),['Staff Tengah','Crew Tengah']);
assert.ok(r.shifts[2].every(x=>x.sourceDate===d20),'Staff and crew same day');
const twoCrew={...roster,staff:[p('0300000003','Crew A','CREW',{[d20]:'M22'},5),p('0300000008','Crew B','CREW',{[d20]:'M22'},6)]};
r=K.calculate(twoCrew,d21);
assert.deepEqual(r.shifts[2].map(x=>x?.name),['Crew B','Crew A'],'No staff: two highest-NIK M22 crew only');
r=K.calculate(twoCrew,d20);
assert.deepEqual(r.shifts[2],[null,null],'Do not take M22 from accounting date H');
assert.ok(r.issues.some(x=>x.includes('tidak mengambil jadwal')));
const oneCrew={...roster,staff:[p('0300000003','Crew A','CREW',{[d20]:'M22'},5)]};
r=K.calculate(oneCrew,d21);
assert.equal(r.shifts[2][0].name,'Crew A');
assert.equal(r.shifts[2][1],null,'Never duplicate a person in two slots');
const staffAlone={...roster,staff:[p('0300000002','Staff A','STAFF',{[d20]:'M22'},3)]};
r=K.calculate(staffAlone,d21);
assert.equal(r.shifts[2][0].role,'STAFF');
assert.equal(r.shifts[2][1],null);
const differentDays={...roster,staff:[p('0300000002','Staff Today','STAFF',{[d21]:'M22'},3),p('0300000003','Crew Yesterday','CREW',{[d20]:'M22'},5),p('0300000004','Crew Today','CREW',{[d21]:'M22'},6)]};
r=K.calculate(differentDays,d21);
assert.equal(r.shifts[2][0].name,'Crew Yesterday');
assert.equal(r.shifts[2][1],null,'Do not mix M22 assignments from two dates');
const yearEnd={...roster,staff:[p('0300000002','Staff 31','STAFF',{'2026-12-31':'M22'},3),p('0300000003','Crew 31','CREW',{'2026-12-31':'M22'},5)],dates:['2026-12-31']};
r=K.calculate(yearEnd,'2027-01-01');
assert.deepEqual(r.shifts[2].map(x=>x?.name),['Staff 31','Crew 31'],'H-1 works across month/year');
console.log('PASS: STAFF+CREW, 2 CREW fallback, no H mixing, no duplicate, date boundary, P7/S14 unchanged');
