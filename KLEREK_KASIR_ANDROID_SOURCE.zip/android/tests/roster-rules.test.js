'use strict';
const assert=require('node:assert/strict');
const K=require('../app/src/main/assets/web/schedule-import.js');
const p=(nik,name,role,codes,order)=>({nik,name,role,codes,order});
const roster={version:1,period:'2026-11',dates:['2026-11-19','2026-11-20'],staff:[
 p('0224042745','Kasir Perempuan A','CASHIER',{'2026-11-20':'P7','2026-11-19':'M22'},1),
 p('0225111111','Kasir Perempuan B','CASHIER',{'2026-11-20':'S14'},2),
 p('0226111111','Kasir Perempuan C','CASHIER',{'2026-11-20':'S14'},3),
 p('0218045659','Crew Lama','CREW',{'2026-11-20':'P7','2026-11-19':'M22'},4),
 p('0224042746','Crew Muda','CREW',{'2026-11-20':'P7','2026-11-19':'M22'},5),
]};
const x=K.calculate(roster,'2026-11-20');
assert.equal(x.shifts[0][0].name,'Kasir Perempuan A','Kasir 1 selalu CASHIER');
assert.equal(x.shifts[0][1].name,'Crew Muda','Kasir 2 CREW dengan NIK numerik tertinggi');
assert.equal(x.shifts[1][0].role,'CASHIER');
assert.equal(x.shifts[1][1].role,'CASHIER','Dua perempuan, tidak mengambil CREW');
assert.equal(x.shifts[2][0].name,'Kasir Perempuan A','Shift 3 menggunakan M22 tanggal sebelumnya');
assert.equal(x.shifts[2][1].nik,'0224042746');
assert.ok(K.compareNik('0224042745','0218045659')>0,'Contoh aturan NIK');
const lacking={...roster,staff:roster.staff.filter(x=>x.role!=='CASHIER')};
const y=K.calculate(lacking,'2026-11-20');
assert.equal(y.shifts[0][0],null);
assert.equal(y.shifts[0][1],null);
assert.ok(y.issues.some(x=>x.includes('TIDAK ADA kasir perempuan')));
console.log('PASS: female priority, two female slots, numeric NIK descending, Shift 3 H-1, missing female alert');
