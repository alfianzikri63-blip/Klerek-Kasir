'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/web/index.html'),'utf8');
function extract(a,b){const i=html.indexOf(a),j=html.indexOf(b,i);assert(i>0&&j>i);return html.slice(i,j)}
const code=[extract('function v459CashierSignature(rows)', 'function cloudUpdateCashierSyncLabels()'),extract('async function cloudRefreshCashiersForDate(){','async function v456RefreshOfficerChecks(){')].join('\n');
let requested=[];let rows=[];let state={date:'2026-11-21',shifts:[0,1,2].map(()=>({cashiers:[0,1].map(()=>({name:'A',nik:'1',rows:[{pickup:0,etrans:0,pln:0}]}))}))};
let cloud={ready:true,storeId:'shopA',cashierFetching:false,cashierReadError:'',user:{id:'reader'},revisions:new Map(),pending:new Map(),sending:new Set(),confirmedRows:new Map(),conflicts:new Map(),client:{from:(tbl)=>({select:(columns)=>({eq:(col,id)=>({in:(field,keys)=>{requested.push({tbl,columns,col,id,field,keys});return Promise.resolve({data:rows,error:null})}})})})}};
const context={cloud,state,history:[],navigator:{onLine:true},CLOUD_SYNC_ERRORS:new Map(),
 cashDoc:(date,si,ci)=>`cashier:${date}:${si+1}:${ci+1}`,financeDoc:(date,si)=>`finance:${date}:${si+1}`,settlementDoc:(date,si)=>`settlement:${date}:${si+1}`,financeStatus:()=>{},page:'calc',selectedShift:0,readN:x=>Number(x)||0,
 clone:x=>JSON.parse(JSON.stringify(x)),scheduleApplyCurrent:()=>{},save:()=>{},cloudRenderIfSafe:()=>{},cloudUpdateCashierSyncLabels:()=>{},cloudUpdateBadge:()=>{},cloudError:e=>e.message,
 cloudQueueCashier:()=>{throw Error('reader cannot write')},v4CanEdit:()=>false,
 V45:{ready:true,date:'2026-11-21'},console,process};
context.assert=assert;context.rows=rows;context.requested=requested;
const test=code+`
(async()=>{
 const key=cashDoc(state.date,0,0);
 rows.splice(0,rows.length,{doc_key:key,revision:1,payload:{name:'CITRA',nik:'111',rows:[{pickup:5000000,etrans:0,pln:0}]},updated_by:'cashier'});
 // Mock cloudApplyDoc as the server-authoritative reducer, used by actual app.
 cloudApplyDoc=row=>{cloud.revisions.set(row.doc_key,row.revision);cloud.confirmedRows.set(row.doc_key,clone(row.payload.rows));state.shifts[0].cashiers[0].rows=clone(row.payload.rows)};
 await cloudRefreshCashiersForDate();
 assert.equal(state.shifts[0].cashiers[0].rows[0].pickup,5000000);
 assert.match(cloudCashierSyncText(0,0),/Tersimpan di Cloud/);
 assert.equal(requested[0].field,'doc_key');
 assert.equal(requested[0].keys.length,12);
 // Later revision must reach another phone independently of the two devices' clocks.
 rows.splice(0,rows.length,{...rows[0],revision:2,payload:{...rows[0].payload,rows:[{pickup:5000000,etrans:0,pln:0},{pickup:1500000,etrans:0,pln:0}]}});
 await cloudRefreshCashiersForDate();
 assert.equal(state.shifts[0].cashiers[0].rows.length,2);
 assert.equal(state.shifts[0].cashiers[0].rows[1].pickup,1500000);
 assert.match(cloudCashierSyncText(0,0),/revisi 2/);
 // A third-party save never replaces an unsent local draft.
 cloud.pending.set(key,{payload:{rows:[{pickup:7000000}]},expected:2});
 rows.splice(0,rows.length,{...rows[0],revision:3,payload:{...rows[0].payload,rows:[{pickup:9000000,etrans:0,pln:0}]}});
 await cloudRefreshCashiersForDate();
 assert.equal(state.shifts[0].cashiers[0].rows[1].pickup,1500000);
 assert.equal(cloud.conflicts.has(key),true);
 console.log('PASS v459: clock-independent authoritative updates to 6.5m, 6 cashier + 3 finance + 3 settlement docs, revision label, protect unsent edits');
})().catch(e=>{console.error(e);process.exitCode=1});`;
vm.runInNewContext(test,context,{filename:'v459-sync-vm.js'});
