-- KLEREK KASIR v4.6.3 - TANPA PERSETUJUAN / VALIDASI PER ROLE
-- Jalankan setelah SQL v4.6.2 dan hotfix COALESCE (bila sebelumnya ada).
-- Mengaktifkan kembali edit untuk laporan lama submitted/approved,
-- TETAPI tetap memverifikasi NIK pemilik slot, nama resmi, dan nomor revisi Cloud.
-- Menghapus hak akses memanggil RPC workflow approval; histori lama tidak dihapus.
-- Tidak membuat akun baru, tidak mengubah data transaksi, tidak mengubah Edge Function login.
-- Buat BACKUP sebelum menjalankan SQL pada database produksi.

BEGIN;

create or replace function public.klerek_put_document(
 p_store_id uuid,p_doc_key text,p_payload jsonb,p_expected_revision bigint
) returns table(revision bigint,updated_at timestamptz)
language plpgsql security definer set search_path='' as $$
declare v_role text;v_rev bigint;v_time timestamptz;v_existing bigint;
 v_shift smallint;v_slot smallint;v_day date;v_old jsonb;v_is_cash boolean;v_is_settlement boolean;v_roster_nik text;
begin
 if auth.uid() is null then raise exception 'Login diperlukan';end if;
 select m.role into v_role from public.klerek_members m where m.store_id=p_store_id and m.user_id=auth.uid();
 if v_role is null then raise exception 'Tidak terdaftar sebagai anggota toko';end if;
 if p_doc_key<>'staff' and p_doc_key !~ '^head:[0-9]{4}-[0-9]{2}-[0-9]{2}$'
 and p_doc_key !~ '^cashier:[0-9]{4}-[0-9]{2}-[0-9]{2}:[123]:[12]$'
 and p_doc_key !~ '^settlement:[0-9]{4}-[0-9]{2}-[0-9]{2}:[123]$' then raise exception 'Kunci dokumen tidak berlaku';end if;
 v_is_cash=p_doc_key like 'cashier:%';
 v_is_settlement=p_doc_key like 'settlement:%';
 if (p_doc_key='staff' or p_doc_key like 'head:%') and v_role='kasir' then raise exception 'Hanya kepala toko/admin boleh mengubah data';end if;
 if v_is_cash then
  v_day=pg_catalog.substr(p_doc_key, 9, 10)::date;
  v_shift=pg_catalog.split_part(p_doc_key,':',3)::smallint;
  v_slot=pg_catalog.split_part(p_doc_key,':',4)::smallint;
  if v_role not in ('kasir','admin','kepala_toko') then raise exception 'ONLY_OWN_CASHIER: akun tidak berhak edit nominal';end if;
  select s.nik into v_roster_nik from public.klerek_daily_slots s where s.store_id=p_store_id and s.work_date=v_day and s.shift=v_shift and s.slot=v_slot;
  if v_roster_nik is null then raise exception 'ROSTER_NOT_PUBLISHED';end if;
  if not exists(select 1 from public.klerek_account_niks n where n.store_id=p_store_id and n.user_id=auth.uid() and n.nik=v_roster_nik) then raise exception 'NOT_YOUR_CASHIER: akun tidak cocok dengan NIK roster';end if;
  if coalesce(p_payload->>'nik','')<>v_roster_nik then raise exception 'NIK_MISMATCH';end if;
  if coalesce(trim(p_payload->>'name'),'')<>(select trim(s.staff_name) from public.klerek_daily_slots s where s.store_id=p_store_id and s.work_date=v_day and s.shift=v_shift and s.slot=v_slot) then raise exception 'NAME_MISMATCH';end if;
  -- v4.6.3: approval lama tidak lagi mengunci nominal kasir. Hak NIK, nama, revisi tetap diperiksa.
  if coalesce(pg_catalog.jsonb_typeof(p_payload->'rows'),'null')<>'array' then raise exception 'Format baris tidak valid';end if;
 end if;
 if v_is_settlement then
  v_day=pg_catalog.split_part(p_doc_key,':',2)::date;
  v_shift=pg_catalog.split_part(p_doc_key,':',3)::smallint;
  if v_role='kasir' then raise exception 'Hanya Pejabat/Admin yang boleh mengedit settlement';end if;
    -- v4.6.3: settlement lama tidak dikunci oleh approval.
  if coalesce(pg_catalog.jsonb_typeof(p_payload->'etrans'),'missing') not in ('null','number')
    or coalesce(pg_catalog.jsonb_typeof(p_payload->'pln'),'missing') not in ('null','number')
  then raise exception 'Format settlement tidak valid';end if;
  if (p_payload->>'etrans')::numeric<0 or (p_payload->>'pln')::numeric<0
    or (p_payload->>'etrans')::numeric>1000000000000 or (p_payload->>'pln')::numeric>1000000000000
  then raise exception 'Nominal settlement harus non-negatif';end if;
 end if;
 if p_payload is null or pg_catalog.jsonb_typeof(p_payload)<>'object' or pg_catalog.octet_length(p_payload::text)>120000 then raise exception 'Payload tidak valid';end if;
 if coalesce(p_expected_revision,-1)<0 then raise exception 'Revision tidak valid';end if;
 select d.revision,d.payload into v_existing,v_old from public.klerek_documents d where d.store_id=p_store_id and d.doc_key=p_doc_key for update;
 if coalesce(v_existing,0)<>p_expected_revision then raise exception 'CLOUD_CONFLICT';end if;
 insert into public.klerek_documents as d(store_id,doc_key,payload,revision,updated_by)
 values(p_store_id,p_doc_key,p_payload,1,auth.uid())
 on conflict(store_id,doc_key) do update set payload=excluded.payload,revision=d.revision+1,updated_at=now(),updated_by=auth.uid()
 where d.revision=p_expected_revision
 returning d.revision,d.updated_at into v_rev,v_time;
 if not found then raise exception 'CLOUD_CONFLICT';end if;
 insert into public.klerek_audit(store_id,actor,item_key,action,before_summary,after_summary)
 values(p_store_id,auth.uid(),p_doc_key,'EDIT',
  case when v_old is null then null else pg_catalog.jsonb_build_object('revision',v_existing,'bytes',pg_catalog.octet_length(v_old::text),'rows',pg_catalog.jsonb_array_length(case when pg_catalog.jsonb_typeof(v_old->'rows')='array' then v_old->'rows' else '[]'::jsonb end)) end,
  pg_catalog.jsonb_build_object('revision',v_rev,'bytes',pg_catalog.octet_length(p_payload::text),'rows',pg_catalog.jsonb_array_length(case when pg_catalog.jsonb_typeof(p_payload->'rows')='array' then p_payload->'rows' else '[]'::jsonb end)));
 return query select v_rev,v_time;
end $$;

CREATE OR REPLACE FUNCTION public.klerek_save_shift_settlement(
  p_store_id uuid,
  p_work_date date,
  p_shift smallint,
  p_payload jsonb,
  p_expected_revision bigint
)
RETURNS TABLE(revision bigint, updated_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $klerek462settle$
DECLARE
  v_role text;
  v_nik text;
  v_key text;
  v_field text;
  v_raw text;
  v_clean jsonb := pg_catalog.jsonb_build_object('mode','cumulative-v2');
  v_prev bigint;
  v_revision bigint;
  v_updated timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'LOGIN_REQUIRED'; END IF;
  IF p_store_id IS NULL OR p_work_date IS NULL OR p_shift IS NULL
     OR p_shift NOT BETWEEN 1 AND 3
     OR p_expected_revision IS NULL OR p_expected_revision < 0 THEN
    RAISE EXCEPTION 'CHECKPOINT_INVALID: parameter';
  END IF;
  IF pg_catalog.jsonb_typeof(p_payload) IS DISTINCT FROM 'object'
     OR p_payload->>'mode' IS DISTINCT FROM 'cumulative-v2'
     OR pg_catalog.octet_length(p_payload::text)>5000
     OR EXISTS(SELECT 1 FROM pg_catalog.jsonb_object_keys(p_payload) AS k(key)
               WHERE k.key NOT IN ('mode','etrans','pln')) THEN
    RAISE EXCEPTION 'CHECKPOINT_INVALID: format dokumen';
  END IF;
  SELECT m.role INTO v_role FROM public.klerek_members AS m
  WHERE m.store_id=p_store_id AND m.user_id=auth.uid();
  IF v_role IS NULL THEN RAISE EXCEPTION 'NOT_STORE_MEMBER'; END IF;
  SELECT n.nik INTO v_nik FROM public.klerek_account_niks AS n
  WHERE n.store_id=p_store_id AND n.user_id=auth.uid() LIMIT 1;
  IF v_nik IS NULL OR NOT EXISTS(
     SELECT 1 FROM public.klerek_daily_slots AS s
     WHERE s.store_id=p_store_id AND s.work_date=p_work_date
       AND s.shift=p_shift AND s.nik=v_nik
  ) THEN
    RAISE EXCEPTION 'NOT_YOUR_SHIFT: hanya NIK petugas shift boleh mengisi settlement';
  END IF;
  -- v4.6.3: checkpoint settlement tidak dipengaruhi status approval lama.
  FOREACH v_field IN ARRAY ARRAY['etrans','pln'] LOOP
    IF NOT (p_payload ? v_field) THEN
      RAISE EXCEPTION 'CHECKPOINT_INVALID: % wajib ada',v_field;
    END IF;
    IF pg_catalog.jsonb_typeof(p_payload->v_field)='null' THEN
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_field,NULL);
    ELSE
      v_raw:=p_payload->>v_field;
      IF pg_catalog.jsonb_typeof(p_payload->v_field) IS DISTINCT FROM 'number'
         OR v_raw !~ '^(0|[1-9][0-9]{0,12})$'
         OR v_raw::numeric>1000000000000 THEN
        RAISE EXCEPTION 'CHECKPOINT_INVALID: nominal % tidak valid',v_field;
      END IF;
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_field,v_raw::bigint);
    END IF;
  END LOOP;

  v_key:='settlement:'||p_work_date::text||':'||p_shift::text;
  SELECT d.revision INTO v_prev FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key=v_key FOR UPDATE;
  IF COALESCE(v_prev,0)<>p_expected_revision THEN
    RAISE EXCEPTION 'CLOUD_CONFLICT: ada revisi baru';
  END IF;
  INSERT INTO public.klerek_documents AS d(store_id,doc_key,payload,revision,updated_by)
  VALUES(p_store_id,v_key,v_clean,1,auth.uid())
  ON CONFLICT(store_id,doc_key) DO UPDATE SET
    payload=EXCLUDED.payload,revision=d.revision+1,
    updated_by=auth.uid(),updated_at=now()
  WHERE d.revision=p_expected_revision
  RETURNING d.revision,d.updated_at INTO v_revision,v_updated;
  IF v_revision IS NULL THEN RAISE EXCEPTION 'CLOUD_CONFLICT'; END IF;
  INSERT INTO public.klerek_audit(store_id,actor,item_key,action,after_summary)
  VALUES(p_store_id,auth.uid(),v_key,'SHIFT_SETTLEMENT_SAVE',
    pg_catalog.jsonb_build_object('revision',v_revision,'date',p_work_date,'shift',p_shift));
  RETURN QUERY SELECT v_revision,v_updated;
END;
$klerek462settle$;


-- Pastikan fungsi hanya dapat dipanggil akun login.
REVOKE ALL ON FUNCTION public.klerek_put_document(uuid,text,jsonb,bigint) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.klerek_put_document(uuid,text,jsonb,bigint) TO authenticated;
REVOKE ALL ON FUNCTION public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint) TO authenticated;

-- Tidak ada aksi submit/approve/reject/reopen yang bisa dipanggil dari aplikasi.
-- Fungsi dan histori lama dibiarkan untuk kebutuhan audit.
REVOKE ALL ON FUNCTION public.klerek_workflow_action(uuid,date,smallint,smallint,text,bigint,text,bigint)
  FROM PUBLIC,anon,authenticated;

COMMIT;

-- Hasil harus TRUE / TRUE / FALSE.
SELECT
  has_function_privilege('authenticated','public.klerek_put_document(uuid,text,jsonb,bigint)','EXECUTE') AS simpan_kasir_diizinkan,
  has_function_privilege('authenticated','public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)','EXECUTE') AS settlement_diizinkan,
  has_function_privilege('authenticated','public.klerek_workflow_action(uuid,date,smallint,smallint,text,bigint,text,bigint)','EXECUTE') AS approval_dinonaktifkan_harus_false;
