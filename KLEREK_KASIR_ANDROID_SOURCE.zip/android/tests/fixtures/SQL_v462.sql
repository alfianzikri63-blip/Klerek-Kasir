-- KLEREK KASIR v4.6.2 — PERHITUNGAN SELISIH SETTLEMENT & SETORAN ADMIN
-- JALANKAN SETELAH SQL v4.6.0 DAN v4.6.1, di project Supabase KLEREK yang benar.
-- BACKUP DATA LEBIH DULU. Dokumen lama TIDAK dihapus.
--
-- Hak akses server (bukan hanya tampilan APK):
--   1. NIK yang tercantum sebagai petugas Shift tersebut boleh input checkpoint
--      settlement eTrans / PLN. Tidak boleh menulis shift orang lain.
--   2. NIK kategori STAFF dalam master Excel terbit boleh input Report 24.
--   3. HANYA akun Admin toko yang telah ditautkan ke NIK boleh input
--      setoran tunai per baris dan jam setor manual.
--   4. CREW/CASHIER tidak boleh mengubah Report 24 atau setoran tunai.
--
-- Dokumen:
--   settlement:YYYY-MM-DD:SHIFT  (mode cumulative-v2; sumber selisih)
--   finance:YYYY-MM-DD:SHIFT     (mode per-shift-v2; report24 + depositRows)
--
-- Settlement aktual: S3=pembuka; S1=checkpoint S1-S3;
--   S2=closing S2-(S1-S3)-S3 (aljabar: closing S2-checkpoint S1).
--   Selisih=total eTrans/PLN dua kasir - settlement aktual shift.
--
-- Data finance versi lama berisi setoran sebagai angka tunggal tanpa jam.
-- Versi baru akan membaca sebagai baris arsip tanpa jam; Admin perlu melengkapi jam.

BEGIN;

CREATE OR REPLACE FUNCTION public.klerek_save_shift_settlement(
  p_store_id uuid,
  p_work_date date,
  p_shift smallint,
  p_payload jsonb,
  p_expected_revision bigint
)
RETURNS TABLE(revision bigint, updated_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $klerek462settle$
DECLARE
  v_role text;
  v_nik text;
  v_key text;
  v_field text;
  v_raw text;
  v_clean jsonb := pg_catalog.jsonb_build_object('mode','cumulative-v2');
  v_prev bigint;
  v_revision bigint;
  v_updated timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'LOGIN_REQUIRED'; END IF;
  IF p_store_id IS NULL OR p_work_date IS NULL OR p_shift IS NULL
     OR p_shift NOT BETWEEN 1 AND 3
     OR p_expected_revision IS NULL OR p_expected_revision < 0 THEN
    RAISE EXCEPTION 'CHECKPOINT_INVALID: parameter';
  END IF;
  IF pg_catalog.jsonb_typeof(p_payload) IS DISTINCT FROM 'object'
     OR p_payload->>'mode' IS DISTINCT FROM 'cumulative-v2'
     OR pg_catalog.octet_length(p_payload::text)>5000
     OR EXISTS(SELECT 1 FROM pg_catalog.jsonb_object_keys(p_payload) AS k(key)
               WHERE k.key NOT IN ('mode','etrans','pln')) THEN
    RAISE EXCEPTION 'CHECKPOINT_INVALID: format dokumen';
  END IF;
  SELECT m.role INTO v_role FROM public.klerek_members AS m
  WHERE m.store_id=p_store_id AND m.user_id=auth.uid();
  IF v_role IS NULL THEN RAISE EXCEPTION 'NOT_STORE_MEMBER'; END IF;
  SELECT n.nik INTO v_nik FROM public.klerek_account_niks AS n
  WHERE n.store_id=p_store_id AND n.user_id=auth.uid() LIMIT 1;
  IF v_nik IS NULL OR NOT EXISTS(
     SELECT 1 FROM public.klerek_daily_slots AS s
     WHERE s.store_id=p_store_id AND s.work_date=p_work_date
       AND s.shift=p_shift AND s.nik=v_nik
  ) THEN
    RAISE EXCEPTION 'NOT_YOUR_SHIFT: hanya NIK petugas shift boleh mengisi settlement';
  END IF;
  IF EXISTS(
    SELECT 1 FROM public.klerek_workflows AS w
    WHERE w.store_id=p_store_id AND w.work_date=p_work_date
      AND w.shift=p_shift AND w.status='approved'
  ) THEN RAISE EXCEPTION 'REPORT_LOCKED: settlement disetujui'; END IF;
  FOREACH v_field IN ARRAY ARRAY['etrans','pln'] LOOP
    IF NOT (p_payload ? v_field) THEN
      RAISE EXCEPTION 'CHECKPOINT_INVALID: % wajib ada',v_field;
    END IF;
    IF pg_catalog.jsonb_typeof(p_payload->v_field)='null' THEN
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_field,NULL);
    ELSE
      v_raw:=p_payload->>v_field;
      IF pg_catalog.jsonb_typeof(p_payload->v_field) IS DISTINCT FROM 'number'
         OR v_raw !~ '^(0|[1-9][0-9]{0,12})$'
         OR v_raw::numeric>1000000000000 THEN
        RAISE EXCEPTION 'CHECKPOINT_INVALID: nominal % tidak valid',v_field;
      END IF;
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_field,v_raw::bigint);
    END IF;
  END LOOP;

  v_key:='settlement:'||p_work_date::text||':'||p_shift::text;
  SELECT d.revision INTO v_prev FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key=v_key FOR UPDATE;
  IF pg_catalog.coalesce(v_prev,0)<>p_expected_revision THEN
    RAISE EXCEPTION 'CLOUD_CONFLICT: ada revisi baru';
  END IF;
  INSERT INTO public.klerek_documents AS d(store_id,doc_key,payload,revision,updated_by)
  VALUES(p_store_id,v_key,v_clean,1,auth.uid())
  ON CONFLICT(store_id,doc_key) DO UPDATE SET
    payload=EXCLUDED.payload,revision=d.revision+1,
    updated_by=auth.uid(),updated_at=now()
  WHERE d.revision=p_expected_revision
  RETURNING d.revision,d.updated_at INTO v_revision,v_updated;
  IF v_revision IS NULL THEN RAISE EXCEPTION 'CLOUD_CONFLICT'; END IF;
  INSERT INTO public.klerek_audit(store_id,actor,item_key,action,after_summary)
  VALUES(p_store_id,auth.uid(),v_key,'SHIFT_SETTLEMENT_SAVE',
    pg_catalog.jsonb_build_object('revision',v_revision,'date',p_work_date,'shift',p_shift));
  RETURN QUERY SELECT v_revision,v_updated;
END;
$klerek462settle$;

REVOKE ALL ON FUNCTION public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)
  FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)
  TO authenticated;

CREATE OR REPLACE FUNCTION public.klerek_save_shift_finance(
  p_store_id uuid,
  p_work_date date,
  p_shift smallint,
  p_payload jsonb,
  p_expected_revision bigint
)
RETURNS TABLE(revision bigint,updated_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $klerek462finance$
DECLARE
  v_role text;
  v_nik text;
  v_staff boolean := false;
  v_admin boolean := false;
  v_master jsonb;
  v_report text;
  v_report_value jsonb;
  v_old_report jsonb;
  v_old_rows jsonb := '[]'::jsonb;
  v_rows jsonb;
  v_clean_rows jsonb := '[]'::jsonb;
  v_row jsonb;
  v_amt text;
  v_time text;
  v_amount jsonb;
  v_clean jsonb;
  v_key text;
  v_prev bigint;
  v_old jsonb;
  v_revision bigint;
  v_updated timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'LOGIN_REQUIRED'; END IF;
  IF p_store_id IS NULL OR p_work_date IS NULL OR p_shift IS NULL
     OR p_shift NOT BETWEEN 1 AND 3
     OR p_expected_revision IS NULL OR p_expected_revision < 0 THEN
    RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: parameter';
  END IF;
  IF pg_catalog.jsonb_typeof(p_payload) IS DISTINCT FROM 'object'
     OR p_payload->>'mode' IS DISTINCT FROM 'per-shift-v2'
     OR pg_catalog.octet_length(p_payload::text)>15000
     OR EXISTS(SELECT 1 FROM pg_catalog.jsonb_object_keys(p_payload) AS f(key)
               WHERE f.key NOT IN ('mode','report24','depositRows')) THEN
    RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: format dokumen';
  END IF;
  SELECT m.role INTO v_role FROM public.klerek_members AS m
  WHERE m.store_id=p_store_id AND m.user_id=auth.uid();
  IF v_role IS NULL THEN RAISE EXCEPTION 'NOT_STORE_MEMBER'; END IF;
  SELECT n.nik INTO v_nik FROM public.klerek_account_niks AS n
  WHERE n.store_id=p_store_id AND n.user_id=auth.uid() LIMIT 1;
  IF v_nik IS NULL THEN RAISE EXCEPTION 'LOGIN_NIK_REQUIRED'; END IF;
  v_admin := v_role='admin';

  SELECT d.payload->'scheduleRoster' INTO v_master
  FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key='staff';
  v_staff:=pg_catalog.coalesce((v_master->>'version'='2'
    AND v_master->>'period'=pg_catalog.to_char(p_work_date,'YYYY-MM')
    AND pg_catalog.jsonb_typeof(v_master->'staff')='array'
    AND EXISTS(
      SELECT 1 FROM pg_catalog.jsonb_array_elements(
        CASE WHEN pg_catalog.jsonb_typeof(v_master->'staff')='array'
          THEN v_master->'staff' ELSE '[]'::jsonb END) AS s(person)
      WHERE s.person->>'nik'=v_nik
        AND pg_catalog.upper(s.person->>'role')='STAFF'
    )),false);
  IF NOT v_staff AND NOT v_admin THEN
    RAISE EXCEPTION 'ONLY_STAFF_NIK: Report 24 untuk STAFF, setoran untuk Admin';
  END IF;
  IF NOT EXISTS(
    SELECT 1 FROM public.klerek_daily_slots AS s
    WHERE s.store_id=p_store_id AND s.work_date=p_work_date
  ) THEN RAISE EXCEPTION 'ROSTER_NOT_PUBLISHED'; END IF;

  IF NOT (p_payload ? 'report24') THEN RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: report24 wajib ada'; END IF;
  IF pg_catalog.jsonb_typeof(p_payload->'report24')='null' THEN
    v_report_value:='null'::jsonb;
  ELSE
    v_report:=p_payload->>'report24';
    IF pg_catalog.jsonb_typeof(p_payload->'report24') IS DISTINCT FROM 'number'
       OR v_report !~ '^(0|[1-9][0-9]{0,12})$' OR v_report::numeric>1000000000000 THEN
      RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: nominal Report 24';
    END IF;
    v_report_value:=pg_catalog.to_jsonb(v_report::bigint);
  END IF;
  IF pg_catalog.jsonb_typeof(p_payload->'depositRows') IS DISTINCT FROM 'array'
     OR pg_catalog.jsonb_array_length(p_payload->'depositRows')>30 THEN
    RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: setoran harus array maksimal 30 baris';
  END IF;
  v_rows:=p_payload->'depositRows';
  FOR v_row IN SELECT value FROM pg_catalog.jsonb_array_elements(v_rows) AS t(value) LOOP
    IF pg_catalog.jsonb_typeof(v_row) IS DISTINCT FROM 'object'
       OR NOT(v_row ? 'amount') OR NOT(v_row ? 'time')
       OR EXISTS(SELECT 1 FROM pg_catalog.jsonb_object_keys(v_row) AS c(key)
                 WHERE c.key NOT IN ('amount','time')) THEN
      RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: baris setoran';
    END IF;
    IF pg_catalog.jsonb_typeof(v_row->'amount')='null' THEN
      v_amount:='null'::jsonb;
    ELSE
      v_amt:=v_row->>'amount';
      IF pg_catalog.jsonb_typeof(v_row->'amount') IS DISTINCT FROM 'number'
         OR v_amt !~ '^(0|[1-9][0-9]{0,12})$' OR v_amt::numeric>1000000000000 THEN
        RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: nominal setoran';
      END IF;
      v_amount:=pg_catalog.to_jsonb(v_amt::bigint);
    END IF;
    v_time:=v_row->>'time';
    IF v_time IS NULL OR (v_time<>'' AND v_time !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$') THEN
      RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: jam setor harus HH:MM';
    END IF;
    v_clean_rows:=v_clean_rows||pg_catalog.jsonb_build_array(
      pg_catalog.jsonb_build_object('amount',v_amount,'time',v_time));
  END LOOP;

  v_key:='finance:'||p_work_date::text||':'||p_shift::text;
  SELECT d.revision,d.payload INTO v_prev,v_old
  FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key=v_key FOR UPDATE;
  IF pg_catalog.coalesce(v_prev,0)<>p_expected_revision THEN
    RAISE EXCEPTION 'CLOUD_CONFLICT: ada revisi baru';
  END IF;
  v_old_report:=pg_catalog.coalesce(v_old->'report24','null'::jsonb);
  IF pg_catalog.jsonb_typeof(v_old->'depositRows')='array' THEN
    v_old_rows:=v_old->'depositRows';
  ELSIF pg_catalog.jsonb_typeof(v_old->'setoran')='number' THEN
    -- Dokumen v4.6.1: satu angka lama, jam belum dicatat. Minta Admin melengkapi.
    v_old_rows:=pg_catalog.jsonb_build_array(
      pg_catalog.jsonb_build_object('amount',v_old->'setoran','time',''));
  END IF;
  IF NOT v_staff AND v_report_value IS DISTINCT FROM v_old_report THEN
    RAISE EXCEPTION 'ONLY_STAFF_NIK: Report 24 hanya NIK STAFF';
  END IF;
  IF NOT v_admin AND v_clean_rows IS DISTINCT FROM v_old_rows THEN
    RAISE EXCEPTION 'ONLY_ADMIN_DEPOSIT: setoran tunai hanya akun Admin';
  END IF;
  v_clean:=pg_catalog.jsonb_build_object('mode','per-shift-v2',
    'report24',v_report_value,'depositRows',v_clean_rows);
  -- Arsip field settlement per-shift lama sebelum menjadi otomatis dari checkpoint.
  -- Tidak dapat diubah dari klien; hanya dicatat ketika pertama kali bermigrasi.
  IF v_old ? 'legacyV461' THEN
    v_clean:=v_clean||pg_catalog.jsonb_build_object('legacyV461',v_old->'legacyV461');
  ELSIF v_old->>'mode'='per-shift-v1' THEN
    v_clean:=v_clean||pg_catalog.jsonb_build_object('legacyV461',v_old);
  END IF;
  INSERT INTO public.klerek_documents AS d(store_id,doc_key,payload,revision,updated_by)
  VALUES(p_store_id,v_key,v_clean,1,auth.uid())
  ON CONFLICT(store_id,doc_key) DO UPDATE SET
    payload=EXCLUDED.payload,revision=d.revision+1,
    updated_by=auth.uid(),updated_at=now()
  WHERE d.revision=p_expected_revision
  RETURNING d.revision,d.updated_at INTO v_revision,v_updated;
  IF v_revision IS NULL THEN RAISE EXCEPTION 'CLOUD_CONFLICT'; END IF;
  INSERT INTO public.klerek_audit(store_id,actor,item_key,action,after_summary)
  VALUES(p_store_id,auth.uid(),v_key,'SHIFT_FINANCE_SAVE',
    pg_catalog.jsonb_build_object('revision',v_revision,'shift',p_shift,'date',p_work_date,
      'deposit_count',pg_catalog.jsonb_array_length(v_clean_rows)));
  RETURN QUERY SELECT v_revision,v_updated;
END;
$klerek462finance$;

REVOKE ALL ON FUNCTION public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)
  FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)
  TO authenticated;

-- Realtime untuk dokumen yang sama, tanpa mengubah data historis.
DO $klerek462pub$
BEGIN
  IF NOT EXISTS(SELECT 1 FROM pg_catalog.pg_publication_tables
    WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='klerek_documents') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.klerek_documents;
  END IF;
END
$klerek462pub$;

COMMIT;

-- Semua hasil harus TRUE, tetapi lakukan uji dengan akun STAFF, CREW, Admin di APK juga.
SELECT
  pg_catalog.to_regprocedure('public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)') IS NOT NULL AS checkpoint_rpc,
  pg_catalog.to_regprocedure('public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)') IS NOT NULL AS finance_rpc,
  pg_catalog.has_function_privilege('authenticated',
    'public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)','EXECUTE') AS petugas_boleh_panggil,
  NOT pg_catalog.has_function_privilege('anon',
    'public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)','EXECUTE') AS anonim_diblokir,
  EXISTS(SELECT 1 FROM pg_catalog.pg_publication_tables
    WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='klerek_documents') AS realtime_aktif;
