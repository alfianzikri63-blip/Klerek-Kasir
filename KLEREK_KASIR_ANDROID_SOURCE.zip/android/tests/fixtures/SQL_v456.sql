-- KLEREK KASIR v4.5.6 - PEJABAT MENGISI DULU + REALTIME DUA ARAH
-- JALANKAN SETELAH SQL v4.5.4 pada project Supabase KLEREK yang sama.
-- Backup sebelum menjalankan. Tidak menghapus laporan dan tidak mengganti password.
-- Input Pejabat tetap independen, hak tulis hanya role admin/kepala_toko.
-- Hasil sama/selisih baru dinilai setelah dokumen KASIR tersimpan di Cloud.
-- Real-time hanya dibagikan kepada anggota toko lewat kebijakan RLS yang sudah ada.

BEGIN;

CREATE OR REPLACE FUNCTION public.klerek_officer_save_lines(
 p_store_id uuid, p_work_date date, p_shift smallint, p_slot smallint,
 p_lines jsonb, p_expected_revision bigint
) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_row jsonb;
 v_lines jsonb := '[]'::jsonb;
 v_p bigint;
 v_e bigint;
 v_l bigint;
 v_pickup bigint := 0;
 v_etrans bigint := 0;
 v_pln bigint := 0;
 v_current bigint;
 v_result bigint;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS (
  SELECT 1 FROM public.klerek_members m
  WHERE m.store_id=p_store_id AND m.user_id=auth.uid() AND m.role IN ('admin','kepala_toko')
 ) THEN RAISE EXCEPTION 'Hanya Pejabat/Admin'; END IF;
 IF p_shift IS NULL OR p_slot IS NULL OR p_work_date IS NULL
    OR p_shift NOT BETWEEN 1 AND 3 OR p_slot NOT BETWEEN 1 AND 2
 THEN RAISE EXCEPTION 'Tanggal/slot tidak valid'; END IF;
 IF pg_catalog.jsonb_typeof(p_lines) IS DISTINCT FROM 'array'
 THEN RAISE EXCEPTION 'Input Pejabat harus berupa daftar baris'; END IF;
 IF pg_catalog.jsonb_array_length(p_lines) NOT BETWEEN 1 AND 40
 THEN RAISE EXCEPTION 'Input Pejabat harus 1-40 baris'; END IF;
 -- Pejabat boleh menyimpan lebih dahulu tanpa dokumen kasir.
 -- Pencocokan hasil akhir tetap dievaluasi setelah kedua hitungan tersedia.

 FOR v_row IN SELECT value FROM pg_catalog.jsonb_array_elements(p_lines) LOOP
  IF pg_catalog.jsonb_typeof(v_row) IS DISTINCT FROM 'object'
   OR coalesce(v_row->>'pickup','') !~ '^(0|[1-9][0-9]{0,12})$'
   OR coalesce(v_row->>'etrans','') !~ '^(0|[1-9][0-9]{0,12})$'
   OR coalesce(v_row->>'pln','') !~ '^(0|[1-9][0-9]{0,12})$'
  THEN RAISE EXCEPTION 'Baris Pejabat tidak valid'; END IF;
  v_p=(v_row->>'pickup')::bigint;
  v_e=(v_row->>'etrans')::bigint;
  v_l=(v_row->>'pln')::bigint;
  IF greatest(v_p,v_e,v_l)>1000000000000 THEN
   RAISE EXCEPTION 'Nominal melebihi batas'; END IF;
  v_pickup=v_pickup+v_p;
  v_etrans=v_etrans+v_e;
  v_pln=v_pln+v_l;
  v_lines=v_lines||pg_catalog.jsonb_build_array(
   pg_catalog.jsonb_build_object('pickup',v_p,'etrans',v_e,'pln',v_l)
  );
 END LOOP;
 IF greatest(v_pickup,v_etrans,v_pln)>1000000000000 THEN
  RAISE EXCEPTION 'Total setiap kolom maksimal 1 triliun'; END IF;

 SELECT c.revision INTO v_current
 FROM public.klerek_officer_checks c
 WHERE c.store_id=p_store_id AND c.work_date=p_work_date AND c.shift=p_shift AND c.slot=p_slot FOR UPDATE;
 IF coalesce(v_current,0)<>coalesce(p_expected_revision,-1) THEN
  RAISE EXCEPTION 'OFFICER_CONFLICT: muat ulang hitungan Pejabat'; END IF;

 INSERT INTO public.klerek_officer_checks AS c
  (store_id,work_date,shift,slot,pickup,etrans,pln,lines,officer_id,revision)
 VALUES (p_store_id,p_work_date,p_shift,p_slot,v_pickup,v_etrans,v_pln,v_lines,auth.uid(),1)
 ON CONFLICT (store_id,work_date,shift,slot) DO UPDATE SET
  pickup=EXCLUDED.pickup,etrans=EXCLUDED.etrans,pln=EXCLUDED.pln,
  lines=EXCLUDED.lines,officer_id=auth.uid(),revision=c.revision+1,updated_at=now()
 WHERE c.revision=p_expected_revision
 RETURNING revision INTO v_result;
 IF v_result IS NULL THEN RAISE EXCEPTION 'OFFICER_CONFLICT'; END IF;

 INSERT INTO public.klerek_audit(store_id,actor,item_key,action,after_summary)
 VALUES (p_store_id,auth.uid(),
  'officer:'||p_work_date||':'||p_shift||':'||p_slot,
  'OFFICER_COMPARE',
  pg_catalog.jsonb_build_object('pickup',v_pickup,'etrans',v_etrans,'pln',v_pln,
  'net',v_pickup-v_etrans-v_pln,'rows',pg_catalog.jsonb_array_length(v_lines)));
 RETURN v_result;
END $$;
REVOKE ALL ON FUNCTION public.klerek_officer_save_lines(uuid,date,smallint,smallint,jsonb,bigint) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.klerek_officer_save_lines(uuid,date,smallint,smallint,jsonb,bigint) TO authenticated;

-- Izinkan menerima perubahan segera dengan Postgres Changes pada tabel yang
-- sudah memiliki kebijakan RLS toko (jangan pakai akses anon atau policy true).
DO $v456_pub$
BEGIN
 IF NOT EXISTS (
   SELECT 1 FROM pg_catalog.pg_publication_tables
   WHERE pubname='supabase_realtime' AND schemaname='public'
   AND tablename='klerek_officer_checks'
 ) THEN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.klerek_officer_checks;
 END IF;
 IF NOT EXISTS (
   SELECT 1 FROM pg_catalog.pg_publication_tables
   WHERE pubname='supabase_realtime' AND schemaname='public'
   AND tablename='klerek_documents'
 ) THEN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.klerek_documents;
 END IF;
END;
$v456_pub$;

COMMIT;

-- HASIL VERIFIKASI: kolom fungsi_tersedia, realtime_pejabat,
-- realtime_kasir, rls_pejabat, dan izin_baca_pejabat harus TRUE.
SELECT
 to_regprocedure('public.klerek_officer_save_lines(uuid,date,smallint,smallint,jsonb,bigint)') IS NOT NULL AS fungsi_tersedia,
 EXISTS (SELECT 1 FROM pg_catalog.pg_publication_tables
  WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='klerek_officer_checks') AS realtime_pejabat,
 EXISTS (SELECT 1 FROM pg_catalog.pg_publication_tables
  WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='klerek_documents') AS realtime_kasir,
 (SELECT relrowsecurity FROM pg_catalog.pg_class WHERE oid='public.klerek_officer_checks'::regclass) AS rls_pejabat,
 has_table_privilege('authenticated','public.klerek_officer_checks','SELECT') AS izin_baca_pejabat;

-- PENGUJIAN MANUAL (dilakukan setelah update APK):
-- 1. Buka HP pejabat, pilih tanggal dan slot dengan kasir belum input.
-- 2. Isi Pickup / eTrans / PLN lalu Simpan Validasi Pejabat.
-- 3. Status harus 'Tersimpan · Menunggu kasir' (bukan 'Selisih').
-- 4. HP kasir masuk NIK sesuai roster lalu input, tunggu tersimpan Cloud.
-- 5. Status pejabat & kasir berubah jadi SESUAI / SELISIH dari hasil NET.
-- 6. Perbedaan komponen boleh selama hasil akhir sama.
-- 7. Pastikan kasir tetap tidak bisa mengedit nilai pejabat.
