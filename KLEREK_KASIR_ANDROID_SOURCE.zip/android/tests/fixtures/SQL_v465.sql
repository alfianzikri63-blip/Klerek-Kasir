-- KLEREK KASIR v4.6.5 - PERBAIKAN HAK INPUT SELISIH SETTLEMENT
-- Jalankan pada project Supabase KLEREK/Kasir yang benar SETELAH SQL v4.6.3.
-- Perubahan hanya pada RPC klerek_save_shift_settlement.
-- Aturan: NIK STAFF pada master Excel terbit untuk bulan kerja dapat input
-- eTrans/PLN di semua shift; akun ADMIN toko dengan NIK tertaut juga.
-- NIK CREW/CASHIER hanya untuk shift yang benar-benar ditugaskan.
-- Tetap wajib anggota toko, NIK tertaut, roster tanggal diterbitkan,
-- validasi angka, audit dan optimistic revision check. Tidak ada approval.
-- Report 24 dan setoran tunai TIDAK DIUBAH.
-- Backup database sebelum memasang di produksi.

BEGIN;

CREATE OR REPLACE FUNCTION public.klerek_save_shift_settlement(
  p_store_id uuid,
  p_work_date date,
  p_shift smallint,
  p_payload jsonb,
  p_expected_revision bigint
)
RETURNS TABLE(revision bigint, updated_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $klerek462settle$
DECLARE
  v_role text;
  v_nik text;
  v_master jsonb;
  v_staff boolean := false;
  v_on_shift boolean := false;
  v_key text;
  v_field text;
  v_raw text;
  v_clean jsonb := pg_catalog.jsonb_build_object('mode','cumulative-v2');
  v_prev bigint;
  v_revision bigint;
  v_updated timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'LOGIN_REQUIRED'; END IF;
  IF p_store_id IS NULL OR p_work_date IS NULL OR p_shift IS NULL
     OR p_shift NOT BETWEEN 1 AND 3
     OR p_expected_revision IS NULL OR p_expected_revision < 0 THEN
    RAISE EXCEPTION 'CHECKPOINT_INVALID: parameter';
  END IF;
  IF pg_catalog.jsonb_typeof(p_payload) IS DISTINCT FROM 'object'
     OR p_payload->>'mode' IS DISTINCT FROM 'cumulative-v2'
     OR pg_catalog.octet_length(p_payload::text)>5000
     OR EXISTS(SELECT 1 FROM pg_catalog.jsonb_object_keys(p_payload) AS k(key)
               WHERE k.key NOT IN ('mode','etrans','pln')) THEN
    RAISE EXCEPTION 'CHECKPOINT_INVALID: format dokumen';
  END IF;
  SELECT m.role INTO v_role FROM public.klerek_members AS m
  WHERE m.store_id=p_store_id AND m.user_id=auth.uid();
  IF v_role IS NULL THEN RAISE EXCEPTION 'NOT_STORE_MEMBER'; END IF;
  SELECT n.nik INTO v_nik FROM public.klerek_account_niks AS n
  WHERE n.store_id=p_store_id AND n.user_id=auth.uid() LIMIT 1;
  IF v_nik IS NULL THEN RAISE EXCEPTION 'LOGIN_NIK_REQUIRED'; END IF;
  -- Pastikan tanggal kerja sudah memiliki penugasan yang diterbitkan.
  IF NOT EXISTS(
    SELECT 1 FROM public.klerek_daily_slots AS s
    WHERE s.store_id=p_store_id AND s.work_date=p_work_date
  ) THEN RAISE EXCEPTION 'ROSTER_NOT_PUBLISHED'; END IF;
  -- Master STAFF berasal dari dokumen staf milik toko yang disimpan server,
  -- bukan dari role/metadata yang dikirim sendiri oleh klien.
  SELECT d.payload->'scheduleRoster' INTO v_master
  FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key='staff';
  v_staff:=pg_catalog.coalesce((
    v_master->>'version'='2'
    AND v_master->>'period'=pg_catalog.to_char(p_work_date,'YYYY-MM')
    AND pg_catalog.jsonb_typeof(v_master->'staff')='array'
    AND EXISTS (
      SELECT 1 FROM pg_catalog.jsonb_array_elements(
        CASE WHEN pg_catalog.jsonb_typeof(v_master->'staff')='array'
        THEN v_master->'staff' ELSE '[]'::jsonb END
      ) AS st(person)
      WHERE st.person->>'nik'=v_nik
        AND pg_catalog.upper(pg_catalog.btrim(st.person->>'role'))='STAFF'
    )
  ),false);
  SELECT EXISTS(
    SELECT 1 FROM public.klerek_daily_slots AS s
    WHERE s.store_id=p_store_id AND s.work_date=p_work_date
      AND s.shift=p_shift AND s.nik=v_nik
  ) INTO v_on_shift;
  IF NOT (v_staff OR v_role='admin' OR v_on_shift) THEN
    RAISE EXCEPTION 'NOT_YOUR_SHIFT: hanya STAFF, Admin, atau NIK petugas shift';
  END IF;
  -- v4.6.3: checkpoint settlement tidak dipengaruhi status approval lama.
  FOREACH v_field IN ARRAY ARRAY['etrans','pln'] LOOP
    IF NOT (p_payload ? v_field) THEN
      RAISE EXCEPTION 'CHECKPOINT_INVALID: % wajib ada',v_field;
    END IF;
    IF pg_catalog.jsonb_typeof(p_payload->v_field)='null' THEN
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_field,NULL);
    ELSE
      v_raw:=p_payload->>v_field;
      IF pg_catalog.jsonb_typeof(p_payload->v_field) IS DISTINCT FROM 'number'
         OR v_raw !~ '^(0|[1-9][0-9]{0,12})$'
         OR v_raw::numeric>1000000000000 THEN
        RAISE EXCEPTION 'CHECKPOINT_INVALID: nominal % tidak valid',v_field;
      END IF;
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_field,v_raw::bigint);
    END IF;
  END LOOP;

  v_key:='settlement:'||p_work_date::text||':'||p_shift::text;
  SELECT d.revision INTO v_prev FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key=v_key FOR UPDATE;
  IF COALESCE(v_prev,0)<>p_expected_revision THEN
    RAISE EXCEPTION 'CLOUD_CONFLICT: ada revisi baru';
  END IF;
  INSERT INTO public.klerek_documents AS d(store_id,doc_key,payload,revision,updated_by)
  VALUES(p_store_id,v_key,v_clean,1,auth.uid())
  ON CONFLICT(store_id,doc_key) DO UPDATE SET
    payload=EXCLUDED.payload,revision=d.revision+1,
    updated_by=auth.uid(),updated_at=now()
  WHERE d.revision=p_expected_revision
  RETURNING d.revision,d.updated_at INTO v_revision,v_updated;
  IF v_revision IS NULL THEN RAISE EXCEPTION 'CLOUD_CONFLICT'; END IF;
  INSERT INTO public.klerek_audit(store_id,actor,item_key,action,after_summary)
  VALUES(p_store_id,auth.uid(),v_key,'SHIFT_SETTLEMENT_SAVE',
    pg_catalog.jsonb_build_object('revision',v_revision,'date',p_work_date,'shift',p_shift));
  RETURN QUERY SELECT v_revision,v_updated;
END;
$klerek462settle$;

REVOKE ALL ON FUNCTION public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)
  FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)
  TO authenticated;

COMMIT;

-- Pastikan hasil true: RPC tetap tersedia untuk akun login.
SELECT has_function_privilege('authenticated',
  'public.klerek_save_shift_settlement(uuid,date,smallint,jsonb,bigint)',
  'EXECUTE') AS settlement_rpc_aktif;
