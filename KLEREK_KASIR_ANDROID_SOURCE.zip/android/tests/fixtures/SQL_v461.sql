-- KLEREK KASIR v4.6.1 — HAK INPUT AKHIR SHIFT KHUSUS STAFF
-- Backup database dahulu. Jalankan SETELAH SQL v4.6.0. Tidak mengubah nominal yang telah tersimpan.
-- Tidak memodifikasi/hapus tabel atau dokumen settlement lama.
-- Data baru disimpan pada klerek_documents: finance:YYYY-MM-DD:SHIFT.
-- Penulisan hanya untuk NIK yang pada master Excel TERBIT ber-role STAFF.
-- Admin/Kepala Toko tidak mendapat pengecualian jika NIK mereka bukan STAFF.
-- Satu NIK STAFF boleh mengisi hasil Shift 1, 2, atau 3. CREW/CASHIER baca-saja.
-- Seluruh anggota toko yang telah berizin baca dokumen bisa melihat rekap.

BEGIN;

CREATE OR REPLACE FUNCTION public.klerek_save_shift_finance(
  p_store_id uuid,
  p_work_date date,
  p_shift smallint,
  p_payload jsonb,
  p_expected_revision bigint
)
RETURNS TABLE(revision bigint, updated_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $klerek461$
DECLARE
  v_role text;
  v_nik text;
  v_roster jsonb;
  v_key text;
  v_txt text;
  v_clean jsonb := pg_catalog.jsonb_build_object('mode','per-shift-v1');
  v_doc_key text;
  v_previous_revision bigint;
  v_revision bigint;
  v_updated timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'LOGIN_REQUIRED: masuk dengan NIK terlebih dahulu';
  END IF;
  IF p_store_id IS NULL OR p_work_date IS NULL OR p_shift NOT BETWEEN 1 AND 3 OR p_shift IS NULL
     OR p_expected_revision IS NULL OR p_expected_revision < 0 THEN
    RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: parameter tidak valid';
  END IF;
  IF pg_catalog.jsonb_typeof(p_payload) IS DISTINCT FROM 'object' THEN
    RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: objek input tidak valid';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_catalog.jsonb_object_keys(p_payload) AS f(key)
             WHERE f.key NOT IN ('mode','report24','etrans','pln','setoran')) THEN
    RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: nama kolom tidak dikenali';
  END IF;
  IF p_payload->>'mode' IS DISTINCT FROM 'per-shift-v1' THEN
    RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: format per shift tidak sesuai';
  END IF;
  SELECT m.role INTO v_role
  FROM public.klerek_members AS m
  WHERE m.store_id=p_store_id AND m.user_id=auth.uid();
  IF v_role IS NULL THEN
    RAISE EXCEPTION 'NOT_STORE_MEMBER: bukan anggota toko';
  END IF;
  -- Identitas STAFF dipercaya hanya dari roster Cloud yang diterbitkan.
  -- Jangan menerima role yang dikirim dari browser / metadata user.
  SELECT n.nik INTO v_nik
  FROM public.klerek_account_niks AS n
  WHERE n.store_id=p_store_id AND n.user_id=auth.uid()
  LIMIT 1;
  IF v_nik IS NULL THEN
    RAISE EXCEPTION 'ONLY_STAFF_NIK: akun belum terhubung ke NIK Excel';
  END IF;

  SELECT d.payload->'scheduleRoster' INTO v_roster
  FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key='staff';
  IF v_roster IS NULL OR v_roster->>'version' IS DISTINCT FROM '2'
     OR v_roster->>'period' IS DISTINCT FROM pg_catalog.to_char(p_work_date,'YYYY-MM')
     OR pg_catalog.jsonb_typeof(v_roster->'staff') IS DISTINCT FROM 'array' THEN
    RAISE EXCEPTION 'ROSTER_STAFF_NOT_READY: master Excel bulan ini belum tersedia di Cloud';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_catalog.jsonb_array_elements(v_roster->'staff') AS s(person)
    WHERE s.person->>'nik'=v_nik AND pg_catalog.upper(s.person->>'role')='STAFF'
  ) THEN
    RAISE EXCEPTION 'ONLY_STAFF_NIK: hanya pegawai kategori STAFF yang boleh mengisi akhir shift';
  END IF;
  -- Bulan kerja harus benar-benar diterbitkan sebagai roster harian,
  -- sehingga draf master lokal saja tidak cukup untuk memberikan akses.
  IF NOT EXISTS (
    SELECT 1 FROM public.klerek_daily_slots AS slot
    WHERE slot.store_id=p_store_id AND slot.work_date=p_work_date
  ) THEN
    RAISE EXCEPTION 'ROSTER_NOT_PUBLISHED: jadwal tanggal ini belum diterbitkan';
  END IF;

  FOREACH v_key IN ARRAY ARRAY['report24','etrans','pln','setoran'] LOOP
    IF NOT (p_payload ? v_key) THEN
      RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: kolom % wajib ada',v_key;
    END IF;
    v_txt := p_payload->>v_key;
    IF v_txt IS NULL THEN
      IF pg_catalog.jsonb_typeof(p_payload->v_key) <> 'null' THEN
        RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: % bukan nilai null',v_key;
      END IF;
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_key,NULL);
    ELSE
      IF pg_catalog.jsonb_typeof(p_payload->v_key) <> 'number'
         OR v_txt !~ '^(0|[1-9][0-9]{0,12})$'
         OR v_txt::numeric > 1000000000000 THEN
        RAISE EXCEPTION 'SHIFT_FINANCE_INVALID: nominal % harus 0 sampai 1 triliun',v_key;
      END IF;
      v_clean := v_clean || pg_catalog.jsonb_build_object(v_key,v_txt::bigint);
    END IF;
  END LOOP;

  v_doc_key := 'finance:'||p_work_date::text||':'||p_shift::text;
  SELECT d.revision INTO v_previous_revision
  FROM public.klerek_documents AS d
  WHERE d.store_id=p_store_id AND d.doc_key=v_doc_key FOR UPDATE;
  IF pg_catalog.coalesce(v_previous_revision,0) <> p_expected_revision THEN
    RAISE EXCEPTION 'CLOUD_CONFLICT: ada input lebih baru di HP lain';
  END IF;
  INSERT INTO public.klerek_documents AS d(store_id,doc_key,payload,revision,updated_by)
  VALUES (p_store_id,v_doc_key,v_clean,1,auth.uid())
  ON CONFLICT(store_id,doc_key) DO UPDATE SET
    payload=EXCLUDED.payload,revision=d.revision+1,
    updated_by=auth.uid(),updated_at=now()
  WHERE d.revision=p_expected_revision
  RETURNING d.revision,d.updated_at INTO v_revision,v_updated;
  IF v_revision IS NULL THEN
    RAISE EXCEPTION 'CLOUD_CONFLICT: tidak dapat menimpa revisi terbaru';
  END IF;

  INSERT INTO public.klerek_audit(store_id,actor,item_key,action,after_summary)
  VALUES(p_store_id,auth.uid(),v_doc_key,'SHIFT_FINANCE_SAVE',
    pg_catalog.jsonb_build_object('revision',v_revision,'shift',p_shift,'date',p_work_date));

  RETURN QUERY SELECT v_revision,v_updated;
END;
$klerek461$;

REVOKE ALL ON FUNCTION public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)
FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)
TO authenticated;

-- Klerek_documents sudah berada pada publication v4.5.6. Pastikan tetap aktif:
DO $publication$
BEGIN
  IF NOT EXISTS(
    SELECT 1 FROM pg_catalog.pg_publication_tables
    WHERE pubname='supabase_realtime'
      AND schemaname='public' AND tablename='klerek_documents'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.klerek_documents;
  END IF;
END
$publication$;

COMMIT;

-- Semua kolom pemeriksaan teknis harus TRUE.
-- Uji izin STAFF vs CREW di APK dan Supabase; query ini bukan simulasi role.
SELECT
  pg_catalog.to_regprocedure('public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)') IS NOT NULL AS fungsi_akhir_shift,
  pg_catalog.has_function_privilege('authenticated','public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)','EXECUTE') AS kasir_diizinkan_rpc,
  NOT pg_catalog.has_function_privilege('anon','public.klerek_save_shift_finance(uuid,date,smallint,jsonb,bigint)','EXECUTE') AS anonim_diblokir,
  EXISTS(SELECT 1 FROM pg_catalog.pg_publication_tables
    WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='klerek_documents') AS dokumen_realtime;

-- Catatan: ini menambah fungsi RPC yang aman dan menggunakan dokumen terpisah.
-- Angka settlement lama TIDAK otomatis dipindahkan karena pembuka/akumulasi
-- berbeda makna dari total setiap shift. Masukkan kembali angka riil per shift.
