'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/web/index.html'),'utf8');
const begin=src.indexOf('const V45=');
const end=src.indexOf('const V4=',begin);
assert(begin>-1&&end>begin,'officer functions found');
const context={
 cloud:{ready:true,storeId:'shop1',revisions:new Map()},
 state:{date:'2026-11-21',shifts:[{cashiers:[{name:'CITRA',rows:[{pickup:100000,etrans:20000,pln:10000}]}]}]},
 cashDoc:(date,si,ci)=>`cashier:${date}:${si+1}:${ci+1}`,
 totals:cashier=>{
   const rows=cashier.rows||[];
   const pickup=rows.reduce((s,r)=>s+Number(r.pickup||0),0);
   const etrans=rows.reduce((s,r)=>s+Number(r.etrans||0),0);
   const pln=rows.reduce((s,r)=>s+Number(r.pln||0),0);
   return {pickup,etrans,pln,net:pickup-etrans-pln};
 },
 money:n=>'Rp '+String(n),
 fmt:n=>String(n),
 esc:n=>String(n),
 v4IsManager:()=>true
};
const test=`${src.slice(begin,end)}
V45.ready=true;V45.date=state.date;
const cashierDoc=cashDoc(state.date,0,0);
const htmlBefore=v45OfficerPanel(0,0);
assert.match(htmlBefore,/Simpan Validasi Pejabat/);
assert.match(htmlBefore,/Pejabat boleh mengisi dan menyimpan lebih dulu/);
assert.doesNotMatch(htmlBefore,/Hitungan kasir belum tersimpan di Cloud\. Validasi belum dapat disimpan/);
assert.doesNotMatch(htmlBefore,/data-v45-save="0,0" disabled/);
assert.equal(v45Difference(0,0),null);
V45.checks.set('1:1',{pickup:110000,etrans:30000,pln:10000,revision:1,lines:[{pickup:110000,etrans:30000,pln:10000}]});
assert.match(v45MatchLabel(0,0),/Tersimpan · Menunggu kasir/);
assert.match(v45Badge(0,0),/Menunggu kasir mengirim/);
cloud.revisions.set(cashierDoc,1);
assert.equal(v45Difference(0,0).match,true);
assert.match(v45Badge(0,0),/SESUAI HASIL KLEREK/);
V45.checks.set('1:1',{pickup:110000,etrans:20000,pln:10000,revision:2});
assert.equal(v45Difference(0,0).match,false);
assert.match(v45Badge(0,0),/SELISIH HASIL KLEREK/);
assert.equal(v45Difference(0,0).diff.net,-10000);
v4IsManager=()=>false;
const readonly=v45OfficerPanel(0,0);
assert.ok(readonly.includes('Hanya Admin/Kepala Toko yang dapat mengubah validasi ini'));
assert.doesNotMatch(readonly,/data-v45-save/);
assert.doesNotMatch(readonly,/data-v45-money/);
`;
context.assert=assert;
vm.runInNewContext(test,context,{filename:'officer-tests.js'});
assert.match(src, /table:'klerek_officer_checks',filter:'store_id=eq\.'/);
assert.match(src,/function v456RefreshOfficerChecks/);
assert.match(src, /'✓ Hitungan Pejabat tersimpan\. Menunggu kasir mengisi\.'/);
const sql=fs.readFileSync('/mnt/data/KLEREK_SQL_PEJABAT_DULU_REALTIME_v4_5_6.txt','utf8');
assert.doesNotMatch(sql,/THEN RAISE EXCEPTION 'Kasir belum menyimpan laporan ke Cloud'/);
assert.match(sql,/ALTER PUBLICATION supabase_realtime ADD TABLE public\.klerek_officer_checks/);
assert.match(sql,/m\.role IN \('admin','kepala_toko'\)/);
console.log('PASS: independent officer input before cashier, server guard removed, net match only when cashier cloud exists, realtime events, fallback, RLS-preserving RPC');
