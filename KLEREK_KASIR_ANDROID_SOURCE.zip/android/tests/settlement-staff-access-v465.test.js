'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const base=path.resolve(__dirname,'../app/src/main/assets/web/index.html');
const html=fs.readFileSync(base,'utf8');
const sql=fs.readFileSync(path.join(__dirname,'fixtures/SQL_v465.sql'),'utf8');
const start=html.indexOf('function canEditShiftSettlement(si){');
const end=html.indexOf('function shiftSettlementCard(si){',start);
assert(start>0&&end>start);
const person={user_id:'user-1',nik:'12345'};
const ctx={
 cloud:{ready:true,role:'kasir',user:{id:'user-1'}},
 V4:{ready:true,patchMissing:false},
 V45:{ready:true,date:'2026-11-21',links:[person],slots:[{shift:3,nik:'99999'},{shift:2,nik:'12345'}]},
 activeSchedule:{version:2,period:'2026-11',staff:[{nik:'12345',role:'STAFF'}]},
 state:{date:'2026-11-21'},
};
vm.createContext(ctx);
vm.runInContext(html.slice(html.lastIndexOf('// v4.6.5:',start),end),ctx);
const allowed=si=>vm.runInContext(`canEditShiftSettlement(${si})`,ctx);
assert.deepEqual([allowed(0),allowed(1),allowed(2)],[true,true,true],'STAFF can edit all three shifts');
ctx.activeSchedule.staff[0].role='CREW';
assert.deepEqual([allowed(0),allowed(1),allowed(2)],[false,true,false],'CREW limited to assigned shift');
ctx.activeSchedule.staff[0].role='CASHIER';
assert.deepEqual([allowed(0),allowed(1),allowed(2)],[false,true,false],'CASHIER limited to assigned shift');
ctx.cloud.role='admin';
assert.deepEqual([allowed(0),allowed(1),allowed(2)],[true,true,true],'Admin with linked NIK edits all shifts');
ctx.V45.links=[];
assert.deepEqual([allowed(0),allowed(1),allowed(2)],[false,false,false],'Admin without linked NIK rejected');
ctx.V45.links=[person]; ctx.cloud.role='kasir';
ctx.activeSchedule.staff[0].role='STAFF'; ctx.activeSchedule.period='2026-10';
assert.deepEqual([allowed(0),allowed(1),allowed(2)],[false,true,false],'Old month STAFF record not enough, assigned shift still valid');
ctx.activeSchedule.period='2026-11'; ctx.V45.date='2026-11-20';
assert.equal(allowed(0),false,'Stale date blocked');
ctx.V45.date='2026-11-21';ctx.V4.ready=false;
assert.equal(allowed(0),false,'Cloud verification loading blocked');
assert.equal(allowed(3),false,'Invalid shift blocked');
assert.match(sql,/v_staff OR v_role='admin' OR v_on_shift/);
assert.match(sql,/v_master->>'period'=pg_catalog.to_char\(p_work_date,'YYYY-MM'\)/);
assert.match(sql,/s\.store_id=p_store_id AND s\.work_date=p_work_date/);
assert.match(sql,/LOGIN_NIK_REQUIRED/);
assert.match(sql,/ROSTER_NOT_PUBLISHED/);
assert.match(sql,/CLOUD_CONFLICT/);
assert.match(sql,/REVOKE ALL ON FUNCTION public\.klerek_save_shift_settlement/);
assert.match(html,/const APP_VERSION='4\.6\.5'/);
console.log('PASS v4.6.5: STAFF/Admin all shifts, CREW/CASHIER assigned shift only, linked NIK/date guards, server checks retained');
