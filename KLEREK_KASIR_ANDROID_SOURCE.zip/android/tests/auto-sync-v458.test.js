'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/web/index.html'),'utf8');
const start=html.indexOf('const V458_OFFICER_DRAFT_KEY=');
const end=html.indexOf('async function v451CreateAccount(nik)',start);
assert(start>0&&end>start,'find automatic officer save implementation');
const code=html.slice(start,end);
const db=new Map(),storage=new Map();
let calls=0,failNext=null;
const cloud={ready:true,storeId:'test-shop',user:{id:'manager'},pending:new Map(),sending:new Set(),conflicts:new Map(),client:{rpc:async(name,p)=>{
 assert.equal(name,'klerek_officer_save_lines');assert.equal(p.p_store_id,'test-shop');calls++;
 if(failNext){const message=failNext;failNext=null;return {error:{message}};}
 const key=`${p.p_work_date}:${p.p_shift}:${p.p_slot}`;
 const previous=db.get(key);
 if((previous?.revision||0)!==p.p_expected_revision)return {error:{message:'OFFICER_CONFLICT'}};
 const revision=(previous?.revision||0)+1;
 db.set(key,{revision,lines:p.p_lines});
 return {data:revision,error:null};
}}};
const rows=[{pickup:5000000,etrans:0,pln:0}];
const context={cloud,navigator:{onLine:true},state:{date:'2026-11-21'},V45:{ready:true,date:'2026-11-21',checks:new Map(),drafts:new Map(),autoDraftKeys:new Set(),autoExpected:new Map(),autoTimers:new Map(),autoSending:new Set(),autoErrors:new Map(),autoSaved:new Set()},
 clone:o=>JSON.parse(JSON.stringify(o)),v4IsManager:()=>true,v45DraftKey:(si,ci)=>`${cloud.storeId}:${context.state.date}:${si+1}:${ci+1}`,v45CheckKey:(si,ci)=>`${si+1}:${ci+1}`,v45Check:(si,ci)=>context.V45.checks.get(`${si+1}:${ci+1}`),
 totals:o=>{let pickup=0,etrans=0,pln=0;for(let r of o.rows){pickup+=r.pickup;etrans+=r.etrans;pln+=r.pln;}return {pickup,etrans,pln,net:pickup-etrans-pln}},
 cloudError:e=>e.message,cloudUpdateBadge:()=>{},cloudRenderIfSafe:()=>{},document:{querySelectorAll:()=>[]},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},
 setTimeout:()=>1,clearTimeout:()=>{},console};
context.assert=assert;context.rows=rows;context.db=db;context.getCalls=()=>calls;
const test=`${code}\n(async()=>{
 const key=v45DraftKey(0,0);
 V45.drafts.set(key,clone(rows));v458OfficerQueue(0,0);
 assert(V45.autoDraftKeys.has(key),'input automatically enqueues without button');
 assert.equal(getCalls(),0,'no immediate write for mid-typing changes');
 await v458OfficerFlush(0,0);
 assert.equal(getCalls(),1,'the automatic flush writes data');
 assert.equal(db.get('2026-11-21:1:1').lines[0].pickup,5000000);
 assert.equal(V45.autoDraftKeys.size,0);
 assert.match(v458OfficerStatus(0,0),/Tersimpan otomatis/);
 // Second edit after successful save uses updated revision
 const updated=[{pickup:6000000,etrans:400000,pln:0}];
 V45.drafts.set(key,clone(updated));v458OfficerQueue(0,0);
 await v458OfficerFlush(0,0);
 assert.equal(db.get('2026-11-21:1:1').revision,2);
 assert.equal(db.get('2026-11-21:1:1').lines[0].pickup,6000000);
 // Editing while disconnected must preserve draft and send on reconnect
 navigator.onLine=false;V45.drafts.set(key,[{pickup:7000000,etrans:0,pln:0}]);v458OfficerQueue(0,0);
 await v458OfficerFlush(0,0);
 assert.match(v458OfficerStatus(0,0),/Offline/);
 assert.equal(db.get('2026-11-21:1:1').revision,2);
 navigator.onLine=true;await v458OfficerFlush(0,0);
 assert.equal(db.get('2026-11-21:1:1').revision,3);
 assert.equal(db.get('2026-11-21:1:1').lines[0].pickup,7000000);
 // Conflict must retain draft, not overwrite changes made on another device.
 db.set('2026-11-21:1:1',{revision:4,lines:[{pickup:7500000,etrans:0,pln:0}]});
 V45.drafts.set(key,[{pickup:8000000,etrans:0,pln:0}]);v458OfficerQueue(0,0);
 await v458OfficerFlush(0,0);
 assert(V45.autoDraftKeys.has(key));assert.match(v458OfficerStatus(0,0),/KONFLIK/);
 assert.equal(db.get('2026-11-21:1:1').lines[0].pickup,7500000);
 assert.equal(V45.drafts.get(key)[0].pickup,8000000);
 console.log('PASS: autosave officer with no button, revision progression, offline recovery, and no overwrite on conflicts');
})()`;
vm.runInNewContext(test,context,{filename:'test-auto-v458.js'}).catch(e=>{console.error(e);process.exitCode=1});
assert.doesNotMatch(html,/data-v45-save=/,'manual save button is no longer necessary');
assert.match(html,/setInterval\(\(\)=>\{if\(cloud\?\.ready&&navigator\.onLine\)\{v456RefreshOfficerChecks/,'fallback refresh');
assert.match(html,/table:'klerek_officer_checks',filter:'store_id=eq\.'/,'officer realtime subscription retained');
