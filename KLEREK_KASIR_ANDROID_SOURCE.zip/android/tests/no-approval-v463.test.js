'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/web/index.html'),'utf8');
const sql=fs.readFileSync(path.join(__dirname,'fixtures/SQL_v463.sql'),'utf8');
assert.match(html,/const APP_VERSION='4\.6\.3'/);
assert.doesNotMatch(html,/data-v4-submit="/); // No close and submit controls
assert.doesNotMatch(html,/data-v4-review="/); // No approve/reject controls
assert.doesNotMatch(html,/✅ Approval</);
assert.match(html,/function v4CashierActions\(si,ci\)\{return '';\}/);
assert.match(html,/function v4HeadPanel\(\)\{return '';\}/);
assert.match(sql,/REVOKE ALL ON FUNCTION public\.klerek_workflow_action/);
assert.doesNotMatch(sql,/RAISE EXCEPTION 'REPORT_LOCKED/);
assert.match(sql,/not exists\(select 1 from public\.klerek_account_niks n where n\.store_id=p_store_id and n\.user_id=auth\.uid\(\) and n\.nik=v_roster_nik\)/i);
assert.match(sql,/CLOUD_CONFLICT/);
let helpers=html.slice(html.indexOf('function v463SlotCategory('),html.indexOf('function v45OfficerPanel('));
const context={
 V45:{date:'2026-11-21',slots:[],links:[]},
 cloud:{role:'kasir',user:{id:'user1'},members:[]},
 state:{date:'2026-11-21',shifts:[{cashiers:[{nik:'123',name:'A'}, {nik:'124',name:'B'}]}]},
 activeSchedule:{staff:[{nik:'123',role:'STAFF'},{nik:'124',role:'CREW'}]},
 assert,
};
vm.runInNewContext(helpers+`
 assert.equal(v463NeedsOfficerValidation(0,0),false,'STAFF without pejabat validation');
 assert.equal(v463NeedsOfficerValidation(0,1),true,'CREW retains validation');
 V45.slots=[{shift:1,slot:1,nik:'123',job_role:'CASHIER'},{shift:1,slot:2,nik:'124',job_role:'CREW'}];
 V45.links=[{nik:'123',user_id:'user1'},{nik:'124',user_id:'user2'}];
 cloud.role='admin';
 assert.equal(v463NeedsOfficerValidation(0,0),false,'admin on own cashier slot no validation');
 assert.equal(v463NeedsOfficerValidation(0,1),true,'admin viewing crew still sees validation');
`,context);
// Cashier permission uses ownership and ignores obsolete submitted/approved flags.
const start=html.indexOf('function v4CanEdit(');
const end=html.indexOf('function v4Reset(',start);
assert(start>=0&&end>start);
const ownerCtx={
 cloud:{ready:true,role:'admin',user:{id:'user1'}},
 V4:{ready:true,patchMissing:false},
 V45:{ready:true,date:'2026-11-21',slots:[{shift:1,slot:1,nik:'123'},{shift:1,slot:2,nik:'124'}],links:[{nik:'123',user_id:'user1'}]},
 state:{date:'2026-11-21'},assert
};
vm.runInNewContext(html.slice(start,end)+`
 assert.equal(v4CanEdit(0,0),true);
 assert.equal(v4CanEdit(0,1),false);
 cloud.role='kasir';assert.equal(v4CanEdit(0,0),true);
 cloud.role='kepala_toko';assert.equal(v4CanEdit(0,0),true);
`,ownerCtx);
console.log('PASS v4.6.3: no approval UI/RPC, STAFF/Admin bypass officer validation for own slot, CREW keeps it, only linked NIK edits, old lock removed in SQL');
